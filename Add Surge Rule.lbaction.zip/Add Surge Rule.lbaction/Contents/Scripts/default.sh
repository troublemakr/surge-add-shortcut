#!/bin/sh
#
# LaunchBar Action Script
#

source /Users/francisfeng/.bash_profile
/Users/francisfeng/bin/surge-add $1
